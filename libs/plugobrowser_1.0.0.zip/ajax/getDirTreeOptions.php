<?php
require '../config.php';

$plugoBrowser->sendJson(array('dirTree' => $plugoBrowser->getDirTreeOptions()));