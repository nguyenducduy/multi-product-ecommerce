tinyMCE.addI18n('cs.plugobrowser',{
	desc : 'PlugoBrowser'
});