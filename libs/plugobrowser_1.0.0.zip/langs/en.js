tinyMCE.addI18n('en.plugobrowser',{
	desc : 'PlugoBrowser'
});